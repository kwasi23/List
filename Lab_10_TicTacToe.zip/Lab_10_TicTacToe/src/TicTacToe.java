import java.util.Scanner; //This imports the Scanner class from the java.util package, which is used to read input from the user.
class TicTacToe {//This begins the declaration of a new class called TicTacToe
    public static void main(String[] args) {//This is the main method that is called when the program starts.
        char[][] board = new char[3][3];//This creates a two-dimensional array of characters with 3 rows and 3 columns, which represents the game board.
        for (int row = 0; row < board.length; row++) {
            for (int col = 0; col < board[row].length; col++) {
                board[row][col] = ' ';
            }
        }//This initializes each element of the board array to a space character, which represents an empty space on the board.
        char player = '1';//This initializes a variable called player to the character '1', which represents the first player.
        boolean gameOver = false;//This initializes a variable called gameOver to false, which indicates that the game is not over yet.
        Scanner scanner = new Scanner(System.in);//This creates a new Scanner object that reads input from the console.
        while (!gameOver) {//This begins a while loop that continues until gameOver is set to true.
            printBoard(board);//This calls the printBoard method to print the current state of the board to the console.
            System.out.print("Player " + player + " enter: ");//This prints a prompt to the console, asking the current player to enter a row and column to place their piece.
            int row = scanner.nextInt();
            int col = scanner.nextInt();//This reads the user's input for the row and column they want to place their piece in.
            System.out.println();
            if (board[row][col] == ' ') {
                board[row][col] = player; // place the element
                gameOver = haveWon(board, player);
                if (gameOver) {
                    System.out.println("Player " + player + " has won: ");
                } else {

                    player = (player == '1') ? '2' : '1';
                }
            } else {
                System.out.println("Move already made. Try again big bro!");
            }
        }//This checks if the chosen position is empty, and if so, places the current player's piece in that position on the board. Then, it checks if the game has been won by the current player, and if so, prints a message to the console. If the game has not been won, it switches to the next player.
        printBoard(board);
    }
    public static boolean haveWon(char[][] board, char player) {//This line defines a new method called haveWon, which takes in the current state of the board and the current player's symbol.
        // check the rows
        for (int row = 0; row < board.length; row++) {
            if (board[row][0] == player && board[row][1] == player && board[row][2] == player) {
                return true;
            }
        }
        // check for col
        for (int col = 0; col < board[0].length; col++) {
            if (board[0][col] == player && board[1][col] == player && board[2][col] == player) {
                return true;
            }
        }

        // diagonal
        if (board[0][0] == player && board[1][1] == player && board[2][2] == player) {
            return true;
        }
        if (board[0][2] == player && board[1][1] == player && board[2][0] == player) {
            return true;
        }
        return false;
    }
    public static void printBoard(char[][] board) {
        for (int row = 0; row < board.length; row++) {
            for (int col = 0; col < board[row].length; col++) {
                System.out.print(board[row][col] + " | ");
            }
            System.out.println();
        }
    }
}